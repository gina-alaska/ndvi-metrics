#this script defines the environment variables for ndvi_metrics.bash
#directories
export ndvi_data_dir=/home/jiang/nps/cesu/modis_ndvi_250m/TERRA
export work_dir=/home/jiang/nps/cesu/modis_ndvi_250m/wrkdir
export script_dir=/home/jiang/nps/cesu/modis_ndvi_250m/scripts
export idl_prog_dir=/home/jiang/nps/cesu/modis_ndvi_250m/wrkdir/ndvi_new
export result_dir=/home/jiang/nps/cesu/modis_ndvi_250m/wrkdir
export YEAR=2010
